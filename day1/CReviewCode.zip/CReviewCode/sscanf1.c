#include <stdio.h>
#include <stdlib.h>

int main()
{
   char str[]="88 CM3103 123.567";
   int k;
   float v;
   sscanf(str, "%d %s %f", &k, str, &v);
   printf("Extracted integer %d\n",k);
   printf("Extracted string %s\n",str);
   printf("Extracted float %f\n",v);
}
