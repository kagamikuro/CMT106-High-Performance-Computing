#include <stdio.h>
int main()
{
    int x=0;
    do {
        printf( "Hello world!\n" );
    } while ( x != 0 );
}
