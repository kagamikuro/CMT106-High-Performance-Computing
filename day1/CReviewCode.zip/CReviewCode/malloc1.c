#include <stdio.h>
#include <stdlib.h>
int main()
{
    int *pn = malloc(5*sizeof(int));
    pn[0] = 0;
    pn[1] = 1;
    pn[2] = 2;
    pn[3] = 3;
    pn[4] = 4;
    printf("pn = %d,%d,%d,%d,%d\n",pn[0],pn[1],pn[2],pn[3],pn[4]);
    free(pn);
}

