#include <stdio.h>

int square(int n)
{
    return (n*n);
}

int main()
{
    int x = 7;
    int y = square(x);
    printf("The square of %d = %d\n",x,y);
}

