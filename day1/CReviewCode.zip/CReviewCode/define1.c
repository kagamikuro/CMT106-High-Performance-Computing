#include <stdio.h>

#define PI 3.14159265

int main(void)
{
#ifdef PI
    printf("\nPI defined with value %8.6f\n", PI);
#endif
}
