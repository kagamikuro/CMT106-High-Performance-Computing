#include <stdio.h>
int main()
{
    int n=7;
    float v=1.234;
    char a='X';
    printf("n=%d, v=%f, a=%c\n",n,v,a);
}

