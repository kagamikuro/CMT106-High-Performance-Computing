#include <stdio.h>
int main(int argc, char **arg)
{
	printf("The name of the program is %s\n",arg[0]);
	printf("The argument is %s\n",arg[1]);
	printf("The address of the argument is %p\n",arg[1]);
	printf("The first character of the argument is %c\n",*arg[1]);
}
