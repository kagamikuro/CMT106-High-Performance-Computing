#include <stdio.h>

int main()
{
   char str[20];
   int k=123;
   sprintf(str, "Value of k = %d",k);
   printf("%s\n",str);
}
