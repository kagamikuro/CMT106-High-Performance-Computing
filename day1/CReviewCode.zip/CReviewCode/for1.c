#include <stdio.h>
int main()
{
	int i, imax=20;
	for(i=1;i<=imax;i++){
		printf("The square of %2d is %3d\n",i,i*i);
	}
}
