#include <stdio.h>

int main()
{
	int n=77;
	int *pn=&n;
	int **ppn=&pn;
	printf("n=%4d, pn=%p, ppn=%p\n",n,pn,ppn);
	printf("Value stored at pn=%4d\n",*pn);
	printf("Value stored at ppn=%p\n",*ppn);
	printf("Value stored at address pointed to by ppn=%4d\n",**ppn);
}

