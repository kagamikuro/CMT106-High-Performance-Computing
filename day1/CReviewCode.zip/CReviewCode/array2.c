#include <stdio.h>
int main()
{
   int b[10]={0,1,2,3,4,5,6,7,8,9};
   int *pb;
   pb = b+5;
   printf("*pb=%4d\n",*pb);
   printf("pb=%p\n",pb);
   pb = pb +2;
   printf("*pb=%4d\n",*pb);
   printf("pb=%p\n",pb);
}

