#include <stdio.h>
int main()
{
    char s1[]="Hello";
    printf("s1=%s\n",s1);
    printf("s1+1=%s\n",s1+1);
}
