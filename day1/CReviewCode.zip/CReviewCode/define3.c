#include <stdio.h>
#define MAX(a,b) ((a)>(b) ? (a) : (b))
int main()
{
    int i=10, j=22;
    printf("MAX(%d,%d)=%d\n",i,j,MAX(i,j));
}
