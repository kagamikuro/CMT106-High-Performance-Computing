#include <stdio.h>

int main(){
    union u_tag {
	int ival;
	float fval;
	char *pval;
    } uval;
    char str[]="Hello";
    uval.ival = 123;
    uval.fval = 4.567;
    uval.pval = str;
    printf("uval.ival = %d (this is nonsense)\n",uval.ival);
    printf("uval.fval = %f (this is nonsense)\n",uval.fval);
    printf("uval.pval = %s (this is correct)\n",uval.pval);
}
