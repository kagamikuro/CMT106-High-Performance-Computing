#include <stdio.h>
int main()
{
    char s1[6]={'H','e','l','l','o','\0'};
    printf("s1=%s\n",s1);
    printf("s1+1=%s\n",s1+1);
}
