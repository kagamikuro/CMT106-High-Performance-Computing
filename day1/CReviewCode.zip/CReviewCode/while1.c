#include <stdio.h>
#include <math.h>
int main()
{
	int i=1234327;
	float f=sqrt(i);
	int j = ceil(f);
	int n=2, prime = 1;
	while(n<=j){
	    if(i%n==0){
		prime = 0;
		break;
	    }
	    n++;
	}
        if(prime) printf("%d is a prime number\n",i);
	else printf("The smallest divisor of %d is %d\n",i,n);
}
