#include<stdio.h>
int main()
{
	int k;
	float v;
	char carray[20];
	printf("Enter an integer: ");
	scanf("%d",&k);
	printf("%d\n",k);
	printf("Enter a float: ");
	scanf("%f",&v);
	printf("%f\n",v);
	printf("Enter a string of less than 20 characters: ");
	scanf("%s",carray);
	printf("%s\n",carray);
}
