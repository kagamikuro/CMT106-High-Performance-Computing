#include <stdio.h>
int main(void)
{
#ifdef PI
    printf("\nPI defined with value %8.6f\n", PI);
#endif
}
