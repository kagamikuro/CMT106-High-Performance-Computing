#include <stdio.h>

int main(){
    union u_tag {
	int ival;
	float fval;
	char *pval;
    } uval;
    char str[]="Hello";
    uval.ival = 123;
    printf("uval.ival = %d\n",uval.ival);
    uval.fval = 4.567;
    printf("uval.fval = %f\n",uval.fval);
    uval.pval = str;
    printf("uval.pval = %s\n",uval.pval);
}
