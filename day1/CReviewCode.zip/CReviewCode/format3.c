#include <stdio.h>
int main()
{
    int n=77;
    printf("%4d in octal is %o\n",n,n);
    printf("%4d in hex is %x\n",n,n);
}

