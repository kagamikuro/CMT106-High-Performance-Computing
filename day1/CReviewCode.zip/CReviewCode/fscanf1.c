#include <stdio.h>
#include <stdlib.h>

int main()
{
   char str[10];
   int k;
   float v;
   FILE * fp;
   fp = fopen ("file.txt", "w+");
   fputs("88 CM3103 123.567", fp);
   rewind(fp);
   fscanf(fp, "%d %s %f", &k, str, &v);
   printf("Read integer %d\n",k);
   printf("Read string %s\n",str);
   printf("Read float %f\n",v);
   fclose(fp);
}
