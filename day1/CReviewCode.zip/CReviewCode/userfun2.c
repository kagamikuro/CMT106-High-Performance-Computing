#include <stdio.h>
void square(int n, int *m)
{
    *m = n*n;
    return;
}

int main()
{
    int x = 7, y;
    square(x,&y);
    printf("The square of %d = %d\n",x,y);
}


