#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **arg)
{
    if (argc==1){
        printf("Usage: %s s, where s is a string\n",arg[0]);
	exit(1);
    }
    else if (argc >2){
	printf("You have supplied more than one argument");
	printf(" - extra arguments ignored\n");
    }
    printf("The first argument is %s\n",arg[1]);
}
