#include <stdio.h>
int main()
{
    int n=7;
    float v=1.234;
    printf("n=%4d, v=%6.1f\n",n,v);
}

