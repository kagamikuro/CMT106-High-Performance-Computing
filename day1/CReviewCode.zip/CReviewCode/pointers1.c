#include <stdio.h>
int main()
{
    int n, m;
    int *pn;
    n = 77;
    pn = &n;
    m = *pn;
    printf("n=%4d, m=%4d, pn=%p\n",n,m,pn);
}
