double myrand()
{
	double drand48();
	return (drand48());
}
